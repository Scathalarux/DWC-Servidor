<div class="row">  
    <div class="col-12">
        <div class="alert alert-danger">
            <?php echo $texto; ?>
        </div>
    </div>
</div>