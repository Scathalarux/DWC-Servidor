Para utilizar el framework debemos resolver las dependecias. Vamos a la raíz del proyecto y ejecutamos:

composer install

Una vez instalado, debemos poner el proyecto en la raíz de un subdominio tipo ud4.localhost o similar ya que si no, no funcionarán los css y js.
